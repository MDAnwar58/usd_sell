<?php $__env->startSection('fontend'); ?>
    <div class="chat-mian">
        <div class="container-fluid h-100">

            <div class="row justify-content-center h-100">
                <?php if(Session::has('fail') || Session::has('success')): ?>
                    <div class="col-12 text-center">
                        <div class="alert <?php echo e(Session::has('fail') ? 'text-danger' : 'text-success'); ?> ">
                            <?php echo e(Session::has('fail') ? Session::get('fail') : Session::get('success')); ?></div>
                    </div>
                <?php endif; ?>
                <div class="col-md-4 col-xl-3 chat">
                    <div class="card mb-sm-3 mb-md-0 contacts_card">
                        <div class="card-header">
                            <div class="input-group">
                                <input type="text" placeholder="Search..." id="searchInput" class="form-control search">
                                <div class="input-group-prepend">
                                    <span class="input-group-text search_btn"><i class="fas fa-search"></i></span>
                                </div>
                            </div>
                        </div>
                        <div class="card-body contacts_body">
                            <ui class="contacts">
                                <?php $__currentLoopData = $massages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $user_id = $item->from_id == Auth::user()->id ? $item->to_id : $item->from_id;
                                        $photo =
                                            $item->from_id == Auth::user()->id
                                                ? $item->toUser->photo
                                                : $item->fromUser->photo;
                                    ?>
                                    <?php
                                        if ($item->from_id == Auth::user()->id) {
                                            $user_id = $item->toUser->name;
                                        }
                                        if ($item->to_id == Auth::user()->id) {
                                            $user_id = $item->fromUser->name;
                                        }
                                        if ($item->from_id == Auth::user()->id) {
                                            $id_u = $item->toUser->id;
                                        }
                                        if ($item->to_id == Auth::user()->id) {
                                            $id_u = $item->fromUser->id;
                                        }
                                    ?>
                                    <a href="<?php echo e(route('chat', ['user_id' => $id_u])); ?>"
                                        class="chat_list <?php echo e($item->from_id != Auth::user()->id ? 'active' : ''); ?>">
                                        <div class="d-flex bd-highlight">
                                            <div class="img_cont">
                                                <img src="<?php echo e(asset($photo ?? 'https://st4.depositphotos.com/14953852/24787/v/450/depositphotos_247872612-stock-illustration-no-image-available-icon-vector.jpg')); ?>"
                                                    class="rounded-circle user_img" height="40px">
                                            </div>
                                            <div class="user_info">
                                                <span class="text-primary chat_name"><?php echo e($user_id); ?></span><br>
                                                <span><?php echo e($item->massage); ?></span>
                                                <br>
                                                <small class="text-info"><?php echo e($item->created_at->diffForHumans()); ?></small>
                                            </div>
                                        </div>
                                    </a>
                                    <br>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ui>
                        </div>
                        <div class="card-footer"></div>
                    </div>
                </div>
                <div class="col-md-8 col-xl-6 chat">
                    <?php echo $__env->yieldContent('chat'); ?>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var searchInput = document.getElementById('searchInput');

            searchInput.addEventListener('keyup', function() {
                var filter = searchInput.value.toLowerCase();
                var chatList = document.getElementsByClassName('chat_list');

                for (var i = 0; i < chatList.length; i++) {
                    var chatName = chatList[i].getElementsByClassName('chat_name')[0].textContent
                        .toLowerCase();

                    if (chatName.indexOf(filter) > -1) {
                        chatList[i].style.display = '';
                    } else {
                        chatList[i].style.display = 'none';
                    }
                }
            });
        });
    </script>


    </html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.fontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\my project\live project\usd_sell\resources\views/layouts/fontend/chat_master.blade.php ENDPATH**/ ?>