<?php $__env->startSection('chat'); ?>
    <link href="<?php echo e(asset('frontend/assets/css/chat.css')); ?>" rel="stylesheet">

    <div class="card">
        <?php if($user): ?>
            <div class="card-header msg_head">
                <div class="d-flex bd-highlight">
                    <div class="img_cont">
                        <img src="<?php echo e($user->photo ?? 'https://static.turbosquid.com/Preview/001292/481/WV/_D.jpg'); ?>"
                            class="rounded-circle user_img">
                        <span class="online_icon"></span>
                    </div>
                    <div class="user_info">
                        <span>Chat with <?php echo e($user->name); ?></span>
                        <p> #<?php echo e($user->unique_id); ?> </p>
                    </div>
                </div>
                <span id="action_menu_btn" data-bs-toggle="modal" data-bs-target="#exampleModal"><i
                        class="fas fa-ellipsis-v"></i></span>
                <?php echo $__env->make('frontend.info_detials_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>

            <div class="card-body msg_card_body">
                <?php $__currentLoopData = $massages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($item->from_id != Auth::user()->id): ?>
                        <div class="d-flex justify-content-start mb-4">
                            <div class="img_cont_msg">
                                <img src="<?php echo e(asset($item->fromUser->photo ?? 'frontend/assets/no_image.png')); ?>"
                                    class="rounded-circle user_img_msg">
                            </div>
                            <div class="msg_cotainer">
                                <?php echo e($item->massage); ?>

                                <span class="msg_time"><?php echo e($item->created_at->diffForHumans()); ?></span>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="d-flex justify-content-end mb-4">
                            <div class="msg_cotainer_send">
                                <?php echo e($item->massage); ?>

                                <span class="msg_time_send"><?php echo e($item->created_at->diffForHumans()); ?></span>
                            </div>
                            <div class="img_cont_msg">
                                <img src="<?php echo e(asset(Auth::user()->photo ?? 'frontend/assets/no_image.png')); ?>"
                                    class="rounded-circle user_img_msg">
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
            <div class="card-footer">
                <form action="<?php echo e(route('chat.store')); ?>" method="post" class="input-group">
                    <?php echo csrf_field(); ?>
                    <div class="input-group-append">
                        <span class="input-group-text attach_btn"><i class="fas fa-paperclip"></i></span>
                    </div>


                    <input type="hidden" name="from_id" value="<?php echo e(Auth::user()->id); ?>" />
                    <input type="hidden" name="to_id" value="<?php echo e($userId); ?>" />
                    <textarea class="form-control type_msg" name="massage" placeholder="Type your message..."></textarea>
                    <?php $__errorArgs = ['massage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <strong class="text-danger"><?php echo e($massage); ?></strong>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <div class="input-group-append">
                        <span class="input-group-text send_btn"><button class="btn btn-success" type="submit"><i
                                    class="fas fa-location-arrow"></i></button></span>
                    </div>
                </form>
            </div>
        <?php else: ?>
            <h2 class="text-info mt-5 mx-5">New Massage</h2>
        <?php endif; ?>

    </div>
    </div>


    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.fontend.chat_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\my project\live project\usd_sell\resources\views/frontend/chat.blade.php ENDPATH**/ ?>