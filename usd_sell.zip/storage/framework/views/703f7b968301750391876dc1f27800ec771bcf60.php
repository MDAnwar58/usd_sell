<?php $__env->startSection('css'); ?>
    <style>
        .hero {
            background-color: #212531;
            color: #ffffff;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('fontend'); ?>
    <main class="main">
        <section id="hero" class="hero section ">
            <div class="container">
                <div class="row gy-4">
                    <div class="col-lg-6 order-2 order-lg-1 d-flex flex-column justify-content-center  " data-aos="zoom-out">
                        <h3><?php echo e($personal->header); ?></h3>
                        <p class=""><?php echo $personal->header_desc; ?></p>
                        <a class="btn btn-success register-hero" href="<?php echo e(route('user_registration')); ?>"
                            style="width:120px;padding:15px;background-color:#05C55E; ">Register</a>
                    </div>
                    <div class="col-lg-6 order-1 order-lg-2 hero-img" data-aos="zoom-out" data-aos-delay="200">
                        <img src="<?php echo e($personal->background_image); ?>" class="img-fluid animated" alt="">
                    </div>
                </div>
            </div>
        </section><!-- /Hero Section -->
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.fontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\my project\live project\usd_sell\resources\views/frontend/home/index.blade.php ENDPATH**/ ?>