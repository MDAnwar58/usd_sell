@extends('layouts.fontend.master')
@section('fontend')
    <main class="main">
        <section id="hero" class="d-flex justify-content-center my-5">
        <h2 class="m-5 text-danger">For Your Email Verification . We send a massage in your Email. Please Check inbox</h2>
        </section><!-- /Hero Section -->
    </main>
@endsection
