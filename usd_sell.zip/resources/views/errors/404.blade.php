@extends('frontend.home_dashboard')
@section('home')

@section('title') 
404 Page Not Found 
@endsection


<div class="container">
<div class="row">
<div class="col-lg-12">
<h1>404 Page Is Not Found </h1>
</div>
</div>
</div>


@endsection 